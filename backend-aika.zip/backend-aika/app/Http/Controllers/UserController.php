<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Users;

class UserController extends Controller
{
    function get()
    {
        return response()->json(
            [
                "message" => "GET Method Success"
            ]
        );
    }

    function post(Request $request)
    {
        return response()->json(
            [
                "message" => "POST Method Success"
            ]
        );
    }

    function put()
    {
        return response()->json(
            [
                "message" => "PUT Method Success".$id
            ]
        );
    }

    function delete()
    {
        return response()->json(
            [
                "message" => "DELETE Method Success".$id
            ]
        );
    }
}
